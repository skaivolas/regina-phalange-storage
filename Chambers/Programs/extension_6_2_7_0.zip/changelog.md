# Changelog
## 6.2.6

- added dynamic homepage banner

## 6.2.5

- Fixed WebRTC leak