Inkscape guide
==============

Svg2TikZ originally started out as an Inkscape extension and most users will
probably use it this way. 

If installed properly, the extension should appear in the extensions menu. If you
can't find it see the :ref:`inkscape-install` for installation details.



