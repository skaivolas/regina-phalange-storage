
sendCloseNotificationMsg();

/*var supernovaOptions = (function() {

}());
$(document).ready(function () {
 //reload options
});
*/