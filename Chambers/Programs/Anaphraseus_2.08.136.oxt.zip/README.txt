This is release of Anaphraseus with Java Translation Memory storage. It's faster, and have some features unavailable in non-java version.
Added Yandex.Translate, Google Translate API v2, support for Apache OpenOffice 4 and LibreOffice 5.

ChangeLog:

 2019-12-22 09:26 [2.08]  ole_yansen
    * Support for DeepL translator API (https://www.deepl.com/). 
